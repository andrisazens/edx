var mongodb = require('mongodb');
var movies = require('./movies');